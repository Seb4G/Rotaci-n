#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Sprite sprite;
Texture texture;

int main() {

    texture.loadFromFile("plataforma.jpg");
    sprite.setTexture(texture);
    sprite.setOrigin(256/2, 256/2);
    sprite.setPosition(400, 300);

    RenderWindow Ventana(VideoMode(800, 600), "Rotar sprite");

    while (Ventana.isOpen()) {

        Ventana.clear();

        sprite.rotate(0.1);
        Ventana.draw(sprite);

        Ventana.display();
    }

    return 0;
}
